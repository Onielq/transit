/* ═══════════════════════════════════════════════════════════════
   PLATEAU TRANSIT — CLOUDFLARE PAGES FUNCTION
   Replaces the Express + PostgreSQL backend.
   KV schema:
     user:phone:{phone}   → { id, name, phone, passHash, salt }
     user:id:{id}         → same
     token:{tok}          → { userId, expiresAt }
     favs:{userId}        → [{ id, type, ref_id, label, createdAt }]
     tickets:{userId}     → [{ id, routeId, fromStop, toStop,
                               status, payment, momoRef, issuedAt }]
     vpos:{vehicleId}     → { lat, lon, routeId, speed, bearing, ts }
     vpos:route:{routeId} → [vehicleId, ...]
   ═══════════════════════════════════════════════════════════════ */

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
};

/* ── helpers ─────────────────────────────────────────────── */
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS },
  });
}
function err(msg, status = 400) {
  return json({ error: msg }, status);
}

async function hashPassword(password) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key  = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(password),
    'PBKDF2', false, ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100_000, hash: 'SHA-256' },
    key, 256
  );
  return {
    passHash: btoa(String.fromCharCode(...new Uint8Array(bits))),
    salt:     btoa(String.fromCharCode(...salt)),
  };
}

async function verifyPassword(password, passHash, saltB64) {
  const salt = Uint8Array.from(atob(saltB64), c => c.charCodeAt(0));
  const key  = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(password),
    'PBKDF2', false, ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 100_000, hash: 'SHA-256' },
    key, 256
  );
  return btoa(String.fromCharCode(...new Uint8Array(bits))) === passHash;
}

function uuid() {
  return crypto.randomUUID();
}

async function getUser(KV, token) {
  if (!token) return null;
  const tok = token.replace('Bearer ', '');
  const session = await KV.get(`token:${tok}`, 'json');
  if (!session || Date.now() > session.expiresAt) return null;
  return KV.get(`user:id:${session.userId}`, 'json');
}

/* ── router ──────────────────────────────────────────────── */
export async function onRequest(context) {
  const { request, env } = context;
  const KV  = env.PT_KV;
  const url  = new URL(request.url);
  // strip /api prefix
  const path = url.pathname.replace(/^\/api/, '') || '/';
  const method = request.method.toUpperCase();

  if (method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS });
  }

  let body = {};
  if (['POST', 'PUT', 'PATCH'].includes(method)) {
    try { body = await request.json(); } catch {}
  }

  const authHeader = request.headers.get('Authorization') || '';

  /* ── AUTH ─────────────────────────────────────────────── */

  // POST /api/auth/register
  if (method === 'POST' && path === '/auth/register') {
    const { name, phone, password } = body;
    if (!name || !phone || !password) return err('name, phone, password required');
    const existing = await KV.get(`user:phone:${phone}`);
    if (existing) return err('Phone already registered', 409);

    const { passHash, salt } = await hashPassword(password);
    const user = { id: uuid(), name, phone, passHash, salt, createdAt: Date.now() };
    await KV.put(`user:phone:${phone}`, JSON.stringify(user));
    await KV.put(`user:id:${user.id}`, JSON.stringify(user));

    const token = uuid();
    await KV.put(`token:${token}`, JSON.stringify({
      userId: user.id, expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    }), { expirationTtl: 30 * 24 * 3600 });

    return json({ token, user: { id: user.id, name, phone } });
  }

  // POST /api/auth/login
  if (method === 'POST' && path === '/auth/login') {
    const { identifier, password } = body;
    if (!identifier || !password) return err('identifier and password required');
    const raw = await KV.get(`user:phone:${identifier}`, 'json');
    if (!raw) return err('Invalid credentials', 401);
    const ok = await verifyPassword(password, raw.passHash, raw.salt);
    if (!ok) return err('Invalid credentials', 401);

    const token = uuid();
    await KV.put(`token:${token}`, JSON.stringify({
      userId: raw.id, expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    }), { expirationTtl: 30 * 24 * 3600 });

    return json({ token, user: { id: raw.id, name: raw.name, phone: raw.phone } });
  }

  /* ── ARRIVALS ─────────────────────────────────────────── */

  // GET /api/arrivals/:stopId
  const arrMatch = path.match(/^\/arrivals\/(.+)$/);
  if (method === 'GET' && arrMatch) {
    const stopId   = arrMatch[1];
    const limit    = parseInt(url.searchParams.get('limit') || '8');
    const routeIds = await KV.get(`stop:routes:${stopId}`, 'json') || [];
    const data     = [];
    for (const rId of routeIds.slice(0, limit)) {
      const vehIds = await KV.get(`vpos:route:${rId}`, 'json') || [];
      for (const vid of vehIds) {
        const pos = await KV.get(`vpos:${vid}`, 'json');
        if (pos) data.push({ vehicleId: vid, routeId: rId, eta: pos.eta || null, ...pos });
      }
    }
    return json({ data });
  }

  // GET /api/vehicles?route_id=X
  if (method === 'GET' && path === '/vehicles') {
    const routeId = url.searchParams.get('route_id');
    if (!routeId) return err('route_id required');
    const vehIds = await KV.get(`vpos:route:${routeId}`, 'json') || [];
    const data   = [];
    for (const vid of vehIds) {
      const pos = await KV.get(`vpos:${vid}`, 'json');
      if (pos) data.push({ vehicleId: vid, ...pos });
    }
    return json({ data });
  }

  // POST /api/vehicles/report  (driver GPS ping)
  if (method === 'POST' && path === '/vehicles/report') {
    const user = await getUser(KV, authHeader);
    const { route_id, vehicle_id, lat, lon, accuracy_m, speed_kmh, bearing } = body;
    if (!route_id || !lat || !lon) return err('route_id, lat, lon required');

    const vid = vehicle_id || (user ? `drv:${user.id}` : `anon:${uuid()}`);
    const pos = { lat, lon, routeId: route_id, speed: speed_kmh, bearing, accuracy: accuracy_m, ts: Date.now() };
    await KV.put(`vpos:${vid}`, JSON.stringify(pos), { expirationTtl: 300 }); // 5 min TTL

    // Keep route → vehicle index
    let vehIds = await KV.get(`vpos:route:${route_id}`, 'json') || [];
    if (!vehIds.includes(vid)) vehIds.push(vid);
    await KV.put(`vpos:route:${route_id}`, JSON.stringify(vehIds), { expirationTtl: 300 });

    return json({ ok: true, vehicleId: vid });
  }

  /* ── TICKETS ──────────────────────────────────────────── */

  const user = await getUser(KV, authHeader);

  // GET /api/tickets
  if (method === 'GET' && path === '/tickets') {
    if (!user) return err('Unauthorized', 401);
    const status  = url.searchParams.get('status') || 'valid';
    const tickets = (await KV.get(`tickets:${user.id}`, 'json') || [])
      .filter(t => status === 'all' || t.status === status);
    return json({ data: tickets });
  }

  // POST /api/tickets
  if (method === 'POST' && path === '/tickets') {
    if (!user) return err('Unauthorized', 401);
    const { route_id, from_stop_id, to_stop_id, payment_method, momo_ref } = body;
    if (!route_id || !from_stop_id || !to_stop_id) return err('route_id, from_stop_id, to_stop_id required');

    const ticket = {
      id:            uuid(),
      routeId:       route_id,
      fromStop:      from_stop_id,
      toStop:        to_stop_id,
      status:        'valid',
      payment:       payment_method || 'momo',
      momoRef:       momo_ref || null,
      issuedAt:      Date.now(),
      expiresAt:     Date.now() + 2 * 60 * 60 * 1000, // 2h
    };
    const tickets = await KV.get(`tickets:${user.id}`, 'json') || [];
    tickets.push(ticket);
    await KV.put(`tickets:${user.id}`, JSON.stringify(tickets));
    return json({ data: ticket }, 201);
  }

  /* ── USER FAVOURITES ──────────────────────────────────── */

  // GET /api/user/favourites
  if (method === 'GET' && path === '/user/favourites') {
    if (!user) return err('Unauthorized', 401);
    const favs = await KV.get(`favs:${user.id}`, 'json') || [];
    return json({ data: favs });
  }

  // POST /api/user/favourites
  if (method === 'POST' && path === '/user/favourites') {
    if (!user) return err('Unauthorized', 401);
    const { type, ref_id, label } = body;
    if (!type || !ref_id) return err('type and ref_id required');
    const fav = { id: uuid(), type, ref_id, label: label || ref_id, createdAt: Date.now() };
    const favs = await KV.get(`favs:${user.id}`, 'json') || [];
    favs.push(fav);
    await KV.put(`favs:${user.id}`, JSON.stringify(favs));
    return json({ data: fav }, 201);
  }

  // DELETE /api/user/favourites/:id
  const favDelMatch = path.match(/^\/user\/favourites\/(.+)$/);
  if (method === 'DELETE' && favDelMatch) {
    if (!user) return err('Unauthorized', 401);
    const favId = favDelMatch[1];
    const favs  = (await KV.get(`favs:${user.id}`, 'json') || []).filter(f => f.id !== favId);
    await KV.put(`favs:${user.id}`, JSON.stringify(favs));
    return json({ ok: true });
  }

  /* ── SSE — live vehicle positions ───────────────────── */
  // GET /api/stream/vehicles
  // Streams vehicle:position events every 4 s.
  // CF Pages Functions support streaming responses natively.
  if (method === 'GET' && path === '/stream/vehicles') {
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();
    const enc    = new TextEncoder();

    const send = (event, data) =>
      writer.write(enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));

    // Heartbeat + position loop — runs until client disconnects
    (async () => {
      try {
        let ticks = 0;
        while (true) {
          // List active vehicle keys from KV
          const list = await KV.list({ prefix: 'vpos:', limit: 100 });
          for (const key of list.keys) {
            // Skip route-index keys, only emit vehicle position keys
            if (key.name.startsWith('vpos:route:')) continue;
            const vid = key.name.replace('vpos:', '');
            const pos = await KV.get(key.name, 'json');
            if (!pos) continue;
            await send('vehicle:position', {
              vehicle_id: vid,
              route_id:   pos.routeId,
              lat:        pos.lat,
              lon:        pos.lon,
              speed:      pos.speed,
              bearing:    pos.bearing,
              status:     'active',
            });
          }
          // Send heartbeat comment every 20 s to keep connection alive
          if (ticks % 5 === 0) {
            await writer.write(enc.encode(': heartbeat\n\n'));
          }
          ticks++;
          await new Promise(r => setTimeout(r, 4000));
        }
      } catch {
        // Client disconnected — clean up
        try { await writer.close(); } catch {}
      }
    })();

    return new Response(readable, {
      headers: {
        'Content-Type':  'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection':    'keep-alive',
        ...CORS,
      },
    });
  }

  /* ── HEALTH CHECK ────────────────────────────────────── */
  if (method === 'GET' && path === '/health') {
    return json({ status: 'ok', ts: Date.now(), env: 'cloudflare-pages' });
  }

  return err('Not found', 404);
}
