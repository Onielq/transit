# Plateau Transit — Cloudflare Deployment

## Stack
- **Pages** — hosts `index.html` (the PWA)
- **Pages Functions** — `/functions/api/[[route]].js` handles all `/api/*` routes
- **KV** — replaces PostgreSQL for user data, tickets, favourites, vehicle positions

---

## First-time setup

### 1. Install Wrangler
```bash
npm install -g wrangler
wrangler login
```

### 2. Create KV namespace
```bash
wrangler kv namespace create PT_KV
# outputs: id = "abc123..."

wrangler kv namespace create PT_KV --preview
# outputs: preview_id = "def456..."
```

Paste both IDs into `wrangler.toml`.

### 3. Deploy to Pages
```bash
wrangler pages deploy . --project-name=plateau-transit
```

First deploy creates the project. Subsequent deploys update it.

---

## Local dev
```bash
wrangler pages dev . --kv=PT_KV
# App runs at http://localhost:8788
# API at http://localhost:8788/api/health
```

---

## API routes (Pages Function)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/auth/register | — | Create account |
| POST | /api/auth/login | — | Get token |
| GET | /api/arrivals/:stopId | — | ETA at stop |
| GET | /api/vehicles?route_id= | — | Vehicles on route |
| POST | /api/vehicles/report | optional | Driver GPS ping |
| GET | /api/tickets | Bearer | User tickets |
| POST | /api/tickets | Bearer | Buy ticket |
| GET | /api/user/favourites | Bearer | Get favourites |
| POST | /api/user/favourites | Bearer | Add favourite |
| DELETE | /api/user/favourites/:id | Bearer | Remove favourite |
| GET | /api/health | — | Status check |

---

## KV schema

| Key | Value | TTL |
|-----|-------|-----|
| `user:phone:{phone}` | `{ id, name, phone, passHash, salt }` | — |
| `user:id:{id}` | same | — |
| `token:{token}` | `{ userId, expiresAt }` | 30 days |
| `favs:{userId}` | `[{ id, type, ref_id, label }]` | — |
| `tickets:{userId}` | `[{ id, routeId, status, ... }]` | — |
| `vpos:{vehicleId}` | `{ lat, lon, speed, bearing, ts }` | 5 min |
| `vpos:route:{routeId}` | `[vehicleId, ...]` | 5 min |

---

## Notes
- WebSocket (Socket.io) is replaced by polling. The app's WS simulator still runs in demo mode.
  For live WebSocket push, add Cloudflare Durable Objects (paid plan).
- `localStorage` is kept for: demo banner state, demo modal state, error logs.
  All user-account data (auth token, user object) is still stored in `localStorage` on the client
  and validated server-side via KV on each request.
